#!/bin/sh

echo built in parameters


echo $1 $2 $3 $4 
echo "everything $*"
echo "number of parameters $#"
echo "PID $$"
