# !/sh/bin

first=$1
second=$2

expr $first + $second
expr $first - $second
expr $first / $second 
expr $first \* $second
expr $first % $second
