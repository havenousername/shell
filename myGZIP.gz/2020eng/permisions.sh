chmod ugo filename

0 = 0 = nothing
1 = 1 = execute
2 = 2 = write
3 = 2 + 1 = execute and write
4 = 4 = read
5 = 4+1 = read and execute 
6 = 4+2 = read and  write
7 = 4+ 2 +1 = read and  wrote and execute
