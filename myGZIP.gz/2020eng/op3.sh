# !/sh/bin

first=$1
second=$2
result=`expr $first + $second`

echo $result
