#!/bin/sh

for name in Andrew Elephant Sins
do
 echo Great $name
done	

