cat mixed.txt | grep -c "^[0-9]\+$"
