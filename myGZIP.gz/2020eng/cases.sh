#!/bin/sh

if test $# -eq 0
then
 echo No parameters
else
 echo I go paramenters
fi

